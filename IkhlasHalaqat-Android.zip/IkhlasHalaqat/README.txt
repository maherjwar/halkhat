تطبيق حلقات الإخلاص (أندرويد)
1) ثبّت Android Studio (إصدار حديث) وافتح مجلد المشروع IkhlasHalaqat.
2) انتظر انتهاء Gradle Sync (يحتاج إنترنت أول مرة).
3) لتشغيل رمز QR دون إنترنت: نزّل ملف qrcode.min.js (مكتبة qrcode-generator 1.4.4)
   وضعه في app/src/main/assets/ بجوار index.html.
4) شغّل على جهاز/محاكي (Android 10 فأعلى): Run > app
5) لملف APK: Build > Build APK(s). للنشر في Google Play: Build > Generate Signed Bundle.
الملفات المصدّرة تُحفظ في مجلد التنزيلات. البيانات مخزنة داخل التطبيق على الجهاز فقط.
